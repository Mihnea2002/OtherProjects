package com.example.finalproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements
        LoginFragment.OnLoginListener,  // Makes listener for :login events
        MainFragment.OnStartQuizListener,  //   starting the quiz
        QuizFragment.OnQuizCompleteListener,  //   quiz completion events
        ResultFragment.OnHomeButtonListener {  //  home button events

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // content view to the activity_main layout

        if (savedInstanceState == null) {
            loadFragment(new LoginFragment());  // If  no saved instance state, load the LoginFragment
        }
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();  //  new fragment transaction
        transaction.replace(R.id.fragment_container, fragment);  // Replace the fragment_container with the new fragment
        transaction.addToBackStack(null);  // Add the transaction to the back stack, so the user can navigate back
        transaction.commit();  // Commit the transaction
    }

    @Override
    public void onLoginSuccess() {
        loadFragment(new MainFragment());
    }

    @Override
    public void onStartQuiz() {
        loadFragment(new QuizFragment());
    }

    @Override
    public void onQuizComplete(int score, int total, List<Question> questions, List<Integer> userAnswers) {
        ResultFragment resultFragment = new ResultFragment();  // Create a new instance of ResultFragment
        Bundle args = new Bundle();  // Create a new Bundle to pass arguments
        args.putInt("score", score);  // Put the quiz score into the Bundle
        args.putInt("total", total);  // Put the total number of questions into the Bundle
        args.putSerializable("questions", new ArrayList<>(questions));  // Put the list of questions into the Bundle
        args.putIntegerArrayList("userAnswers", new ArrayList<>(userAnswers));  // Put the list of user answers into the Bundle
        resultFragment.setArguments(args);  // Set the arguments for the ResultFragment
        loadFragment(resultFragment);  // Load the ResultFragment with the arguments
    }

    @Override
    public void onHomeButton() {
        getSupportFragmentManager().popBackStack(null, getSupportFragmentManager().POP_BACK_STACK_INCLUSIVE);  // Pop all fragments off the back stack
        loadFragment(new MainFragment());
    }
}
