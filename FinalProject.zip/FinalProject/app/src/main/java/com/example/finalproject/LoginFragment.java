package com.example.finalproject;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginFragment extends Fragment {

    private EditText emailEditText, passwordEditText;
    private Button loginButton, registerButton;
    private OnLoginListener listener;
    private OkHttpClient client;
    private Gson gson;

    // Define an interface to communicate with the activity
    public interface OnLoginListener {
        void onLoginSuccess(); // Method to be implemented by the host activity to handle login success
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // Check if the context (activity) implements OnLoginListener
        if (context instanceof OnLoginListener) {
            listener = (OnLoginListener) context; // Assign the context to the listener
        } else {
            // Throw an exception if the context does not implement the interface
            throw new RuntimeException(context.toString() + " must implement OnLoginListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Initialize OkHttpClient for making network requests
        client = new OkHttpClient();
        // Initialize Gson for JSON serialization/deserialization
        gson = new Gson();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        emailEditText = view.findViewById(R.id.emailEditText);
        passwordEditText = view.findViewById(R.id.passwordEditText);
        loginButton = view.findViewById(R.id.loginButton);
        registerButton = view.findViewById(R.id.registerButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                    Toast.makeText(getActivity(), "Please enter both email and password", Toast.LENGTH_SHORT).show();
                } else {
                    loginUser(email, password);
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(new RegisterFragment());
            }
        });

        return view;
    }

    private void loginUser(String email, String password) {
        String url = "http://10.0.2.2:3000/login";  // Replace with your backend URL
        User user = new User(email, password);
        String json = gson.toJson(user);

        RequestBody body = RequestBody.create(MediaType.get("application/json; charset=utf-8"), json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                getActivity().runOnUiThread(() -> {
                    Toast.makeText(getActivity(), "Login failed", Toast.LENGTH_SHORT).show();
                });
                Log.e("LoginFragment", "Login request failed", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getActivity(), "Login successful: " + responseBody, Toast.LENGTH_SHORT).show();
                        listener.onLoginSuccess();
                    });
                } else {
                    String responseBody = response.body().string();
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getActivity(), "Invalid credentials: " + responseBody, Toast.LENGTH_SHORT).show();
                    });
                    Log.e("LoginFragment", "Login failed: " + responseBody);
                }
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    private static class User {
        private String email;
        private String password;

        public User(String email, String password) {
            this.email = email;
            this.password = password;
        }
    }
}
