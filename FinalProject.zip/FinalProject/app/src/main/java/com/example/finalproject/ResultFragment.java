package com.example.finalproject;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import java.util.List;

public class ResultFragment extends Fragment {

    private OnHomeButtonListener listener;

    public interface OnHomeButtonListener {
        void onHomeButton();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnHomeButtonListener) {
            listener = (OnHomeButtonListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnHomeButtonListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_result, container, false);

        TextView resultTextView = view.findViewById(R.id.resultTextView);
        LinearLayout resultContainer = view.findViewById(R.id.resultContainer);
        Button homeButton = view.findViewById(R.id.homeButton);

        int score = getArguments().getInt("score");
        int total = getArguments().getInt("total");
        List<Question> questions = (List<Question>) getArguments().getSerializable("questions");
        List<Integer> userAnswers = getArguments().getIntegerArrayList("userAnswers");

        resultTextView.setText("You got " + score + " out of " + total + " correct!");

        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            String userAnswer = question.getAnswers()[userAnswers.get(i)];
            String correctAnswer = question.getAnswers()[question.getCorrectAnswerIndex()];

            TextView questionTextView = new TextView(getContext());
            questionTextView.setText((i + 1) + ". " + question.getQuestion());
            questionTextView.setTextSize(16);
            questionTextView.setTextColor(getResources().getColor(android.R.color.black));
            questionTextView.setPadding(0, 8, 0, 8);

            TextView userAnswerTextView = new TextView(getContext());
            userAnswerTextView.setText("Your answer: " + userAnswer);
            userAnswerTextView.setTextSize(14);
            userAnswerTextView.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            userAnswerTextView.setPadding(0, 4, 0, 4);

            TextView correctAnswerTextView = new TextView(getContext());
            correctAnswerTextView.setText("Correct answer: " + correctAnswer);
            correctAnswerTextView.setTextSize(14);
            correctAnswerTextView.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            correctAnswerTextView.setPadding(0, 4, 0, 4);

            TextView explanationTextView = new TextView(getContext());
            explanationTextView.setText("Explanation: " + question.getExplanation());
            explanationTextView.setTextSize(14);
            explanationTextView.setTextColor(getResources().getColor(android.R.color.darker_gray));
            explanationTextView.setPadding(0, 4, 0, 16);

            resultContainer.addView(questionTextView);
            resultContainer.addView(userAnswerTextView);
            resultContainer.addView(correctAnswerTextView);
            resultContainer.addView(explanationTextView);
        }

        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onHomeButton();
            }
        });

        return view;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
