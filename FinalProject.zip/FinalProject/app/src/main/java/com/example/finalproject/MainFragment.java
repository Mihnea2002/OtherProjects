package com.example.finalproject;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;


public class MainFragment extends Fragment {


    private OnStartQuizListener listener;


    public interface OnStartQuizListener {
        void onStartQuiz(); // Method to be implemented by the host activity
    }

    // Called when the fragment is attached to its host activity
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof OnStartQuizListener) {
            listener = (OnStartQuizListener) context; // Assign the activity to the listener
        } else {

            throw new RuntimeException(context.toString() + " must implement OnStartQuizListener");
        }
    }

    // Called to create the view hierarchy associated with the fragment
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        // Find the start button in the inflated layout
        Button startButton = view.findViewById(R.id.startButton);
        // Find the "How It Works"
        Button howItWorksButton = view.findViewById(R.id.howItWorksButton);

        // Set an OnClickListener for the start button
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onStartQuiz(); // Call the onStartQuiz method of the listener
            }
        });

        // Set an OnClickListener for the "How It Works" button
        howItWorksButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadHowItWorksFragment(); // Load the HowItWorksFragment
            }
        });

        return view; // Return the inflated view
    }

    // Method to load the HowItWorksFragment
    private void loadHowItWorksFragment() {
        // Begin a fragment transaction
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        // Replace the current fragment with the HowItWorksFragment
        transaction.replace(R.id.fragment_container, new HowItWorksFragment());
        // Add the transaction to the back stack to allow navigation back
        transaction.addToBackStack(null);
        // Commit the transaction
        transaction.commit();
    }

    // Called when the fragment is detached from its host activity
    @Override
    public void onDetach() {
        super.onDetach();
        listener = null; // Set the listener to null to avoid memory leaks
    }
}
