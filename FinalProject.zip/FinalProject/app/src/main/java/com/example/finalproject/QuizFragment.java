package com.example.finalproject;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class QuizFragment extends Fragment {

    private OnQuizCompleteListener listener;

    public interface OnQuizCompleteListener {
        void onQuizComplete(int score, int total, List<Question> questions, List<Integer> userAnswers);
    }

    private TextView questionTextView;
    private RadioGroup answersGroup;
    private RadioButton answer1, answer2, answer3, answer4;
    private Button nextButton;

    private List<Question> questionPool;
    private List<Question> currentQuiz;
    private List<Integer> userAnswers;
    private int currentQuestionIndex = 0;
    private int score = 0;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnQuizCompleteListener) {
            listener = (OnQuizCompleteListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnQuizCompleteListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        questionPool = new ArrayList<>();
        addQuestionsToPool();


        userAnswers = new ArrayList<>();


        currentQuiz = new ArrayList<>();
        selectRandomQuestions();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz, container, false);
        questionTextView = view.findViewById(R.id.questionTextView);
        answersGroup = view.findViewById(R.id.answersGroup);
        answer1 = view.findViewById(R.id.answer1);
        answer2 = view.findViewById(R.id.answer2);
        answer3 = view.findViewById(R.id.answer3);
        answer4 = view.findViewById(R.id.answer4);
        nextButton = view.findViewById(R.id.nextButton);

        loadQuestion();

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = answersGroup.getCheckedRadioButtonId();
                if (selectedId != -1) {
                    int answerIndex = answersGroup.indexOfChild(view.findViewById(selectedId));
                    userAnswers.add(answerIndex);
                    if (answerIndex == currentQuiz.get(currentQuestionIndex).getCorrectAnswerIndex()) {
                        score++;
                    }
                    currentQuestionIndex++;
                    if (currentQuestionIndex < currentQuiz.size()) {
                        loadQuestion();
                    } else {
                        listener.onQuizComplete(score, currentQuiz.size(), currentQuiz, userAnswers);
                    }
                }
            }
        });

        return view;
    }

    private void loadQuestion() {
        Question currentQuestion = currentQuiz.get(currentQuestionIndex);
        questionTextView.setText(currentQuestion.getQuestion());
        answer1.setText(currentQuestion.getAnswers()[0]);
        answer2.setText(currentQuestion.getAnswers()[1]);
        answer3.setText(currentQuestion.getAnswers()[2]);
        answer4.setText(currentQuestion.getAnswers()[3]);
        answersGroup.clearCheck();
    }

    private void selectRandomQuestions() {
        List<Integer> questionIndices = new ArrayList<>();
        for (int i = 0; i < questionPool.size(); i++) {
            questionIndices.add(i);
        }
        Collections.shuffle(questionIndices);
        for (int i = 0; i < 5; i++) {
            currentQuiz.add(questionPool.get(questionIndices.get(i)));
        }
    }

    private void addQuestionsToPool() {
        questionPool.add(new Question("Let f(n) = n^2, g(n) = nlogn, h(n) = sin(n). Which of the following statements is true? There may be more than one correct answer.",
                new String[]{"f = Θ(g).", "h = o(g).", "f = Ω(h).", "h = O(g)."}, 2,
                "Explanation: f(n) = n^2 grows faster than h(n) = sin(n) because polynomial growth dominates periodic functions. Hence, f = Ω(h)."));

        questionPool.add(new Question("A recursive program satisfies equation T(n) = 9T(n/3) + Θ(n^2). What can we say about T(n)? There may be several correct answers.",
                new String[]{"T(n) = O(nlogn).", "T(n) = Ω(n^2).", "T(n) = Θ(n^2).", "T(n) = O(n^3)."}, 2,
                "Explanation: By the Master Theorem for divide-and-conquer recurrences, when T(n) = aT(n/b) + f(n), here a = 9, b = 3, and f(n) = n^2, the critical exponent c = log_b(a) = log_3(9) = 2. Since f(n) matches the critical exponent, T(n) = Θ(n^2)."));

        questionPool.add(new Question("In which of the following data structures does searching an item have worst-case complexity Θ(logn)? There may be more than one.",
                new String[]{"Linked lists.", "Heaps.", "Red-black trees.", "Splay trees."}, 2,
                "Explanation: Red-black trees are balanced binary search trees that maintain a height of Θ(logn), which gives searching a complexity of Θ(logn)."));

        questionPool.add(new Question("Which binary tree traversal can be used to list all numbers in a binary search tree in sorted order? There may be more than one correct answer.",
                new String[]{"Breadth-first search.", "Preorder.", "Inorder.", "Postorder."}, 2,
                "Explanation: Inorder traversal of a binary search tree visits nodes in non-decreasing order, which means it lists all numbers in sorted order."));

        questionPool.add(new Question("Which of the following sorting methods is not a comparison-based sort? There may be more than one right answer.",
                new String[]{"Quicksort.", "Radix Sort.", "Insertion Sort.", "HeapSort."}, 1,
                "Explanation: Radix Sort is not a comparison-based sort because it groups numbers by individual digit values, rather than comparing them."));

        questionPool.add(new Question("Which of the following problems has an easy algorithm with complexity O(nlogn)? There may be more than one right answer.",
                new String[]{"Given a list L of n integers, find three numbers x,y,z ∈ L (if they exist) such that x+y = z.",
                        "Given a list L of n integers and a target value z, find two numbers in x,y ∈ L (if they exist) such that x +y = z.",
                        "Given a list L of n integers and a target value z, find two numbers in x,y ∈ L (if they exist) such that x −y = z.",
                        "Given a list L of n integers, find three numbers x,y,z ∈ L (if they exist) such that x+y+z = 0."}, 1,
                "Explanation: Finding two numbers in a list that sum to a target value can be solved in O(nlogn) by sorting the list first and then using a two-pointer technique."));

        questionPool.add(new Question("Which is the rank of the permutation ⟨4,1,6,2,3,5⟩ in lexicographic order?",
                new String[]{"376", "378", "380", "720"}, 1,
                "Explanation: The rank of a permutation is found by counting how many permutations would precede it in lexicographic order. For ⟨4,1,6,2,3,5⟩, calculating this gives a rank of 378."));

        questionPool.add(new Question("A message is a sequence of two types of signals: of type A which last for 1 second and of type B which last for 2 seconds. E.g., the message ABAAB lasts 7 seconds. How many different messages last 10 seconds?",
                new String[]{"68", "32", "89", "144"}, 0,
                "Explanation: This is a combinatorial problem that can be solved using dynamic programming or combinatorial counting techniques. For 10 seconds, the number of different messages is 68."));

        questionPool.add(new Question("Analyze the following code:\n" +
                "class A:\n" +
                " def __init__(self, s):\n" +
                " self.s = s\n" +
                " def print(self):\n" +
                " print(s)\n" +
                "a = A(\"Welcome\")\n" +
                "a.print()\n",
                new String[]{"The program has an error because class A does not have a constructor.",
                        "The program has an error because class A should have a print method with signature print(self, s).",
                        "The program has an error because class A should have a print method with signature print(s).",
                        "The program would run if the line print(s) is changed to print(self.s)."}, 3,
                "Explanation: In Python, to access instance variables within a method, you need to use self. Changing print(s) to print(self.s) would correct the code."));

        questionPool.add(new Question("What is the result of the execution of the following code?\n" +
                "x = 2\n" +
                "for i in range(x):\n" +
                " x += 1\n" +
                " print (x)\n",
                new String[]{"0 1 2 3 4 ...", "0 1", "3 4", "0 1 2 3"}, 2,
                "Explanation: The variable x is incremented in each iteration of the loop. Therefore, the output will be 3 4 because x starts at 2 and is incremented in each of the two iterations."));
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}

class Question {
    private String question;
    private String[] answers;
    private int correctAnswerIndex;
    private String explanation; // New field for explanation

    public Question(String question, String[] answers, int correctAnswerIndex, String explanation) {
        this.question = question;
        this.answers = answers;
        this.correctAnswerIndex = correctAnswerIndex;
        this.explanation = explanation; // Initialize the explanation
    }

    public String getQuestion() {
        return question;
    }

    public String[] getAnswers() {
        return answers;
    }

    public int getCorrectAnswerIndex() {
        return correctAnswerIndex;
    }

    public String getExplanation() {
        return explanation; // Getter for the explanation
    }
}
