const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const cors = require('cors');

const app = express();
const port = 3000;
const usersFile = 'users.json';  // File to store user data

app.use(bodyParser.json());
app.use(cors());

// Read users from file
const readUsers = () => {
    if (!fs.existsSync(usersFile)) {
        fs.writeFileSync(usersFile, JSON.stringify([]));
    }
    const data = fs.readFileSync(usersFile);
    return JSON.parse(data);
};

// Write users to file
const writeUsers = (users) => {
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
};

// Register endpoint
app.post('/register', async (req, res) => {
    console.log('Received request:', req.body);  // Log the incoming request
    const { email, password } = req.body;
    try {
        let users = readUsers();
        const existingUser = users.find(user => user.email === email);
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = { email, password: hashedPassword };
        users.push(newUser);
        writeUsers(users);
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        console.error('Error:', error);  // Log any errors
        res.status(500).json({ message: 'Server error' });
    }
});

// Login endpoint
app.post('/login', async (req, res) => {
    console.log('Received login request:', req.body);  // Log the incoming request
    const { email, password } = req.body;
    try {
        let users = readUsers();
        const user = users.find(user => user.email === email);
        if (!user) {
            return res.status(400).json({ message: 'User does not exist' });
        }
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(400).json({ message: 'Invalid password' });
        }
        res.status(200).json({ message: 'Login successful' });
    } catch (error) {
        console.error('Error:', error);  // Log any errors
        res.status(500).json({ message: 'Server error' });
    }
});

app.listen(port, '0.0.0.0', () => {
    console.log(`Server running on port ${port}`);
});
