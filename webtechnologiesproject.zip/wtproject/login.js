async function loginUser() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
  
    const response = await fetch('http://localhost:3000/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });
  
    const result = await response.text();
  
    if (response.ok) {
      console.log(result);
      // Redirect or perform actions after successful login
    } else {
      console.error(result);
      // Handle error cases, show messages, etc.
    }
  }
  