const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');
const path = require('path');  // Added to work with paths

const app = express();
const port = 3000;

// Middleware to parse incoming JSON requests
app.use(bodyParser.json());

// MongoDB connection string
const connectionString = 'mongodb://localhost:27017/project';
const client = new MongoClient(connectionString, { useUnifiedTopology: true });

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Serve the HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});

// Handle form submissions
app.post('/submit', async (req, res) => {
  try {
    await client.connect();
    const { email, password, username } = req.body;

    // Insert user data into MongoDB
    await insertUserData(client, email, password, username);

    res.send('User data successfully inserted into MongoDB');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  } finally {
    await client.close();
  }
});

async function insertUserData(client, email, password, username) {
  const db = client.db();
  const collection = db.collection('project');
  await collection.insertOne({
    email: email,
    password: password,
    username: username
  });
}

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
async function loginUser() {
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  const response = await fetch('http://localhost:3000/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email, password }),
  });

  const result = await response.text();

  if (response.ok) {
    console.log(result);
    // Redirect or perform actions after successful login
  } else {
    console.error(result);
    // Handle error cases, show messages, etc.
  }
}