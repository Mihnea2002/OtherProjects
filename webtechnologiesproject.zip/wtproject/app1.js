const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');
const path = require('path');

const app = express();
const port = 3000;

// Middleware to parse incoming JSON requests
app.use(bodyParser.json());

// MongoDB connection string
const connectionString = 'mongodb://localhost:27017/project';
const client = new MongoClient(connectionString, { useUnifiedTopology: true });

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// ... (other routes and functions)

// Handle form submissions for user login
app.post('/login', async (req, res) => {
  try {
    await client.connect();
    const { email, password } = req.body;

    // Check if the user exists and the password matches
    const user = await getUserByEmail(client, email);

    if (user && user.password === password) {
      res.send('Login successful!');
    } else {
      res.status(401).send('Invalid username or password');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  } finally {
    await client.close();
  }
});

// ... (other functions)

async function getUserByEmail(client, email) {
  const db = client.db();
  const collection = db.collection('project');
  return await collection.findOne({ email: email });
}

// ... (other routes)

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
